# Workshop 3 Emily Arce Picado - Laravel

## Instalado paquetes en el Webserver

´´´bash
sudo apt-get install vim vim-nox curl \
apache2 mariadb-client php8.2 php8.2-curl \
php8.2-bcmath php8.2-mysql php8.2-mcrypt \
php8.2-xml php8.2-zip php8.2-mbstring
´´´

## Creamos una segunda maquina llamada database
con los siguientes comandos

- ´mkdir database´
- ´cd database´
- ´vagrant init debian/bookworm64´
- ´code Vagranfile´ edita la pagina 36
- ´vagrant up´ inicia la maquina 
- ´vagrant shh´abre la maquina
-´cat ~/.ssh/id_rsa.pub´ para ver la llave publica  (se habre desde el home no de la maquina)
-´vagrant ssh´ vuelve a entrar a la maquina
-´nano .ssh/authorized_keys´ para abrir el archivo y agregar una nueva llave publica (ctrl o para guardar, ctrl x para salir)

## Cambiar el nombre del hostname a database

´´´bash
sudo hostnamectl set-hostname database
sudo nano /etc/hosts
´´´

sudo hostnamectl set-hostname database se utiliza para asignar el nombre
sudo nano /etc/hosts en este archivo en la ip 2 cambian el nombre al nombre que se necesita, y se guarda con ctrl o y se cierra con ctrl x

- Tambien se le cambia el nombre de la misma manera a webserver



- ´sudo apt-get update ´(Descargar la lista de paquetes eligibles)

# Instalar mariabd server y mariabd client

## comandos exploratorios
# Entrar a mysql
- ´sudo mysql´ para entrar a mariaDb
- ´show databases;´ para ver las bases de datos
- ´select user, password from mysql.user´

# Crear base de datos

- ´create database lfts;´
- ´create user larabel identified by 'secret;'´ 

# Otorgarle permisos a la base de datos

- ´grant all privileges on lfts.* on larabel´

# Ver permisos 
Desde mysql

- ´show grants for larabel ´
- ´flush privileges;´

# Habilitar las concexiones remotas 
Desde el server 
-´sudo nano -l /etc/mysql/mariadb.conf.d/50-server.conf´ cambia la linea 27 para coemntar esta linea guardamos y salimos 
- ´sudo systemctl restart mysql´ para restaurar la databse

# En la maquina webserver hacemos lo siguiente

- ´mysql -h 192.168.56.11 -u larabel -p´ para realizar la conexion

# Descargar herramientas de crafteo
Primeros pasos 

´´´ bash
php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"


php -r "unlink('composer-setup.php');"
´´´

- ´php -r "if (hash_file('sha384', 'composer-setup.php') === 'dac665fdc30fdd8ec78b38b9800061b4150413ff2e3b6f88543c636f7cd84f6db9189d43a81e5503cda447da73c7e5b6') { echo 'Installer verified'; } else { echo 'Installer corrupt'; unlink('composer-setup.php'); } echo PHP_EOL;"´ huella unica segundo comando, evita utiliza instaladores corruptos  o intalador modificado por un atacante 

- ´php composer-setup.php ´ compila el ejecutable

# Otros comandos importantes 

- ´ssh vagrant@192.168.56.10´ para una maquina en especifico

- ´sudo mkdir -p /opt/composer´ para tener el composer en una carpeta

- ´sudo mv composer.phar /opt/composer/´ mover composer

- ´env $PATH´ muestra las rutas

- ´sudo ln -s /opt/composer/composer.phar /usr/local/bin/composer´ para poder abrir composer de cualquier lado 

- ´composer´ para abrirlo 

- ´curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash´  para instalar nvm

- ´nvm -v´ ver version 

- ´nvm install --lts´ instala la version lts mas reciente de node 















