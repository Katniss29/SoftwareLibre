## WorkShop05 Dot Files, Bash scripting, Cronjobs 

#!/bin/bash

database="northwind"
username="north"
directory="/vagrant/backups"
logfile=$directory/backup.log
filename=$1
timestamp=$(date +"%Y%m%d%H%M%S")

#Metodo para generar mensajes
log_message(){
    local MESSAGE=$1
    echo "$timestamp : $MESSAGE" | tee -a $logfile
}


#Validar la variable de entorno dbpassword este configurada
if [ -z "$dbpassword" ]; then
    echo "Error: La variable de entorno no esta configurada"
    exit 1
fi

#Validar si se introdujo un argumento
if [ -z "$1" ]; then
   filename=${database}_${timestamp}.sql
else
  filename=${database}_${filename}.sql

fi

cd $directory


#Crear el respaldo  de BD

log_message "Iniciando resplado de $database"

if mysqldump -u $username --password=$dbpassword $database > $filename; then

    log_message "Respaldo de $database realizado con éxito en  $filename"

else 
    log_message "Error: Falló el respaldo de $database"
    exit 1
fi
   


#Comprimir el respaldo 

log_message "Iniciando compresión de respaldo"
tar vcfz $filename.tar.gz $filename
log_message "Finaliza ejecución de script de respaldo"

#Eliminar el respaldo comprimido 

log_message "Eliminando archivo no comprimido"
rm $filename

# Mensaje de finalización
log_message "Finaliza ejecución de script de respaldo"


## Configuración del alias


alias ll='ls -alF'
