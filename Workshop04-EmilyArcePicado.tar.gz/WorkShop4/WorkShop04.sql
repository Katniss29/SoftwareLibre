Challenge 1

select id codigo, type_name descripcion from inventory_transaction_types;


Challenge 2

select concat(e.first_name, " " , e.last_name )  as `Vendedor`,
	   count(o.id) as `Cantidad` 
from employees e join orders o  on o.employee_id = e.id 
group by e.id;



Challenge 3 


desc products ;
desc order_details ;


select p.product_code as `Codigo` ,
p.product_name  as `Producto`,
sum(od.quantity) as `Cantidad`
from products p 
join order_details od 
on od.product_id  = p.id 
group by p.id 
order by `Cantidad` desc
limit 10
;


Challenge 4

select count(o.id) as `Cantidad`,
concat(e.first_name , " ", e.last_name) as  `Vendedor`,
sum(od.quantity + od.unit_price) as `Monto`
from invoices i 
join orders o 
on o.id = i.order_id 
join order_details od 
on od.order_id  = o.id 
join employees e 
on e.id = o.employee_id 
where o.status_id <> 0
and od.status_id in (2, 3)
group by e.id 
order by `Cantidad` desc, `Monto` desc;


Challenge 5

select p.product_code as `Codigo`,
p.product_name  as `Producto`,
sum(it.quantity) as `Cantidad`
from  products p 
join inventory_transactions it 
on it.product_id  = p.id 
where it.transaction_type = 1
group by p.id 

Challenge 6

select p.product_code as `Codigo`,
p.product_name  as `Producto`,
sum(it.quantity) as `Cantidad`
from  products p 
join inventory_transactions it 
on it.product_id  = p.id 
where it.transaction_type in (2, 3, 4)
group by p.id 


Challenge 7 (mejorar)


select p.product_code as `Codigo`,
p.product_name  as `Producto`,
itt.type_name as `Tipo`,
DATE_FORMAT(it.transaction_created_date, '%d/%m/%Y')  as `Date`,
sum(it.quantity) as `Cantidad`
from  products p 
join inventory_transactions it 
on it.product_id  = p.id 
join inventory_transaction_types itt 
on itt.id = it.transaction_type 
where  it.transaction_created_date >= '2006/03/22'
and it.transaction_created_date  <= '2006/03/24'
group by p.id , itt.id
order by p.product_name ;


Challenge 8

select p.product_code as `Codigo`,
p.product_name  as `Producto`,
sum(if(it.transaction_type in (1),it.quantity, 0)) as `Ingresos`,
sum(if(it.transaction_type in (2,3,4 ) ,it.quantity, 0)) as `Salidas`,
sum(if(it.transaction_type in (1),it.quantity, 0))  - sum(if(it.transaction_type in (2,3,4 ) ,it.quantity, 0)) as `Disponible`
from  products p 
join inventory_transactions it 
on it.product_id  = p.id 
group by p.id 



