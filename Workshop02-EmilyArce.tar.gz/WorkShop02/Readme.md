# Workshop02 -LAMP

## TUBERIA EN LINUX 

- ´>´  volver la salida de un comando a un archivoVOLCAR LA SALIDA DE UN COMANDO A UN ARCHIVO 
- ´<´ volcar un archivo a un programa 
- ´>>´ volcar la salida de un comando al final de un archivo 
- ´|´ conectar la salida de un comando con la entrada de otro.
- ´tee´ conecta la salida de un programa y la redirige a pantalla y a un archivo (Sobre escribe)
- ´tee -a´ los mismo que el anterior, para escribir al final del archivo sin sobreescribirlo (Agrega al final).
- ´rm´ Elimina carpetas 
- ´chown´ cambia propietario

## Para generar una llave 

Pasos 


1 - Nombre de la llave

```bash
ssh-keygen -t rsa
```

2 - Luego de esto pregunta por una contraseña para mayor seguridad, para buscar la llave se utiliza 


```bash
cd .ssh 
```

2 - Utilizamos cat para ver el contenido del archivo con el siguiente comando 

```bash
cat id_rsa.pub 
```

3 - Muestra la llave privada (Nunca sacar de la maquina)

```bash
cat id_rsa 
```

5 - Copian la llave publica 

Dirigirse a la maquina virtual y pegar la llave.

- ´cd enter´
- ´cd .ssh´
- ´ls -la ´ para ver los archivos 

En este punto observamos los archivo que existen en ssh en el vemos un archivo llamado authorized_keys

- ´Ingresar al archivo authorized_keys´
- ´Abrir con nano autho authorized_keys´

Y pegamos la llave publica 

Con control + o  guardamos y con control + x nos salimos del nano 

En la maquina anfitriona escibimos el siguiente comando 

```bash
ssh vagrant@192.168.56.10
```
 
Le damos yes al siguiente mensaje 


```bash
The authenticity of host '192.168.56.10 (192.168.56.10)' can't be established.
ED25519 key fingerprint is SHA256:vvuqmZlxSts7hubmNI0W7iqmfu9/ucHL4SDVJruFRMw.
This key is not known by any other names.
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
Warning: Permanently added '192.168.56.10' (ED25519) to the list of known hosts.
```
Y despues de eso nos pide la contraseña la ingresamos y en ese momento entramos


EN al maquina anfitriona se verisona y se codifica y en la virtual los instaladores y la dependencias

## Maquinas conectadas 

Cuando ya las dos maquinas estan conectadas correctamente podemor crear un archivo en la maquina anfitrion y los cambios se observan en la maquina virtual.

# Crear una carpeta nueva para crear un index llamado Los patitos.com

```bash
cd webserver
mkdir conf
touch VMs/webserver/sites/lospatitos.com.conf

```

Dirige esta informacion en index.html

- ´echo "los Patitos.com" > index.html´

- ´sudo a2enmod vhost_alias (Habilitar el vhost)´

- ´sudo systemctl restart apache2 (Reiniciar apache )´

## Seguidamente se modifica el vagrantFile

Se agrega en la linea 47 la siguente informacion 

```bash
<VirtualHost *:80>
ServerAdmin webmaster@lospatitos.com
ServerName lospatitos.com

# Indexes + Directory Root.
DirectoryIndex index.php index.html
DocumentRoot /home/vagrant/sites/lospatitos.com

<Directory /home/vagrant/sites/lospatitos.com>
    DirectoryIndex index.php index.html
    AllowOverride All
    Require all granted
</Directory>

ErrorLog ${APACHE_LOG_DIR}/lospatitos.com.error.log
LogLevel warn
CustomLog ${APACHE_LOG_DIR}/lospatitos.com.access.log combined
</VirtualHost>

```

En la maquina virtual seguimos con los siguiente comando 


- ´vagrant halt´ para apagar la maquina
- ´vagrant up´ para iniciar la maquina
- ´vagrant shh´ para entrar a la linea de comandos
- ´cd /vagrant/´ entrar a vagrant
- ´cd confs´ entrar a confs
- ´sudo cp lospatitos.com.conf /etc/apache2/sites-available/´  
- ´sudo apache2ctl -t´ se verifica la ruta
- ´echo "ServerName webserver´ nombre al servidor 

## Ultimos pasos 

 1 - Abrir el cmd como administrador 

 Y colocar los siguientes comandos

 - ´cd drivers´ abrir drivers
 - ´cd etc´ abrir etc
 - ´notepad hosts´ para modificar la ultima linea y agregar 192.168.56.10 lospatitos.com

