# Workshop01 

## Comando para sobrevivir en _Bash_

Los siguientes comandos son elementales en Bash.

- `whoami` : Muestra el nombre del usuario
- `hostname` : Muestra el nombre del equipo
- `pwd` : Imprime el directorio del trabajo
- `cd` : Permite cambiarse de directorio
- `mkdir` : Crear un directorio
- `ls -la` : Muestra una lista detallada de todos los archivos y directorios actual, hasta los ocultos
- `ls -l` : Muestra un listado de los archivos y directorios actuales omitiendo los ocultos 
- `touch[filename]` : Crea un archivo vacío

## Crear directorio de trabajo para el curso ISW811

Para este curso vamos a necesitar como carpeta base un folder llamado _ISW811_, y dentro de este folder vamos a crear otro llamado _VMs_ para albergar todas las máquinas virtuales;
adicionalmente, para cada <<Workshop>>

```bash
cd ~
mkdir ISW811
mkdir -p VMs/webserver/sites/default/images
touch VMs/webserver/sites/default/index.html
mkdir Workshop01
touch Workshop01/Readme.md
```

## Aprovisionar máquina Vagrant
Para crear un _Vagrantfile_ 
```bash
vagrant init debian/bookworm
```

Luego editamos el archivo _Vagrantfile_ para habilitar la red de <<solo anfitirion>> para este propósito  en la linea 35 habilitada de la siguiente manera

```bash
code Vagrantfile abre el Visual studio code 
config.vm.network "private_network", ip: "192.168.56.10"
```

## Luego de modificar el _Vagrantfile_  se arranca la máquina  virtual definida en el Vagrantfile con el siguiente comando.

```bash
vagrant up
```

## Para verificar el estado de la máquina  utilizamos el siguiente comando

```bash
vagrant status
```

## Para permitir el acceso a la máquina virtual para realizar tareas administrativas se utiliza el siguiente comando 

```bash
vagrant ssh
```

## Después de esto se utiliza la búsqueda de paquetes en webserver 

```bash
sudo apt-cache search webserver
```

## Para luego hacer la instalación de apache2

```bash
sudo apt-get install apache2
```

## Después  de la instalación de apache realizamos un ping en la máquina anfitriona con la virtual para así saber que todo  está funcionando correctamente

```bash
ping 192.168.56.10
```

En este punto si uno ingresa en la web con la ip debe aparecer la  página a base de apache

después de esto creamos un index.html con el comando touch lo abrimos con code para modificarlo con una imagen y un título. 

Después de esto en la máquina virtual hacemos un sudo cp  r- /vagrant/sites/default/* . con esto todos los archivos y directorios de una  ubicación de origen a una  ubicación de destino, con todos los permisos necesarios
